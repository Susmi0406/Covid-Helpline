      <!DOCTYPE html>
<html lang="en">
  <head>
    @include("admin.admincss")
  </head>
  <body>
    
    <li> <x-app-layout></x-app-layout></li> 
    <li>
    
    </li>
    <div class="container-scroller">
    <table>
            
                 
     @include("phi.navbar")
     <br>

       
      <form>
        <br>
      <div style="position: relative; top: 60px; right: -60px "> 
      	<table class="table table-dark table-hover">
      		
      		<tr>
      			<th style="padding: 10px">Name</th>
            <th style="padding: 10px">Email</th>
            <th style="padding: 10px">NIC</th>
            <th style="padding: 10px">Phone</th>
            <th style="padding: 10px">Age</th>
            <th style="padding: 10px">Gender</th>
      			<th style="padding: 10px">District</th>
      			<th style="padding: 10px">MOH Area</th>
      			<th style="padding: 10px">PHI Range</th>
           
      		</tr>

          @foreach($data as $details)

      		<tr align="center" >

      			<td>{{$details->name}}</td>
            <td>{{$details->email}}</td>
            <td>{{$details->nic}}</td>
            <td>{{$details->phone}}</td>
            <td>{{$details->age}}</td>
            <td>{{$details->gender}}</td>
      			<td>{{$details->district}}</td>
      			<td>{{$details->moharea}}</td>
      			<td>{{$details->phirange}}</td>
      			
      		</tr>
          @endforeach


      	</table> <br>
        </form> 

    </div>

    
 </div>
     @include("admin.adminscript")

  </body>
</html>
