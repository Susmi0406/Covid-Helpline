
<!DOCTYPE html>
<html lang="en">
  <head>
    @include("admin.admincss")
  </head>
  <body>
    
    <li> <x-app-layout></x-app-layout></li>         
     @include("phi.navbar")
    
     @include("admin.adminscript")
  </body>
</html>