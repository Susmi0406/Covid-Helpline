
<!DOCTYPE html>
<html lang="en">
  <head>
    @include("admin.admincss")
  </head>
  <body>
  	
    <li> <x-app-layout></x-app-layout></li>         
     @include("admin.navbar")
    
     @include("admin.adminscript")
  </body>
</html>