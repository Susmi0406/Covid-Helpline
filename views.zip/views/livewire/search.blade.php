<div>
    <form action="" method="POST" enctype="multipart/from-data" class="form-horizontal">
    	{{ csrf_field() }}
    	<div class="card-body">
    		<div class="form-group">
    		    <div class="col-sm-10">
    			    <label for="status">Select District</label>
                    <select class="form-control">
                        <option value="">Select a Class</option>
                        
                    </select>

    		    </div>
    	    </div>
    	</div>

    	<div class="card-footer">
            <button type="submit" class="btn-btn-primary" wire:loading.attr="disabled"> Seach </button>
            <div wire:Loading>
                Hold on
            </div>
        </div>


    </form>
</div>
